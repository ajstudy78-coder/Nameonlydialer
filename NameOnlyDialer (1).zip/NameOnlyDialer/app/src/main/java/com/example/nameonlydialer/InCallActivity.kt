package com.example.nameonlydialer

import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.VideoProfile
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InCallActivity : AppCompatActivity() {

    private lateinit var tvName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var btnAnswer: Button
    private lateinit var btnEnd: Button
    private lateinit var btnMute: Button
    private lateinit var btnSpeaker: Button

    private var muted = false
    private var speaker = false
    private var label: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        setContentView(R.layout.activity_incall)

        tvName = findViewById(R.id.tvName)
        tvStatus = findViewById(R.id.tvStatus)
        btnAnswer = findViewById(R.id.btnAnswer)
        btnEnd = findViewById(R.id.btnEnd)
        btnMute = findViewById(R.id.btnMute)
        btnSpeaker = findViewById(R.id.btnSpeaker)

        btnAnswer.setOnClickListener {
            CallManager.call?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }
        btnEnd.setOnClickListener {
            val c = CallManager.call ?: return@setOnClickListener
            if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
        }
        btnMute.setOnClickListener {
            muted = !muted
            CallManager.service?.setMuted(muted)
            btnMute.text = if (muted) "Unmute" else "Mute"
        }
        btnSpeaker.setOnClickListener {
            speaker = !speaker
            CallManager.service?.setAudioRoute(
                if (speaker) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE
            )
            btnSpeaker.text = if (speaker) "Earpiece" else "Speaker"
        }
    }

    override fun onStart() {
        super.onStart()
        CallManager.onChange = { runOnUiThread { render() } }
        render()
    }

    override fun onStop() {
        CallManager.onChange = null
        super.onStop()
    }

    private fun render() {
        val call = CallManager.call
        if (call == null) { finish(); return }

        if (label == null) {
            label = ContactResolver.displayLabel(this, CallManager.number())
        }
        tvName.text = label   // <- only the name (or masked number) is ever shown

        val ringing = call.state == Call.STATE_RINGING
        btnAnswer.visibility = if (ringing) android.view.View.VISIBLE else android.view.View.GONE
        btnEnd.text = if (ringing) "Decline" else "End call"

        tvStatus.text = when (call.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
            Call.STATE_ACTIVE -> "In call"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Ending…"
            else -> ""
        }
    }
}
