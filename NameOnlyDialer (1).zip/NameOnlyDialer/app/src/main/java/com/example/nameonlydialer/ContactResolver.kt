package com.example.nameonlydialer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class Entry(val name: String, val number: String)

object ContactResolver {

    private fun canReadContacts(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED

    /** Returns the saved contact name for a number, or null if not saved. */
    fun nameFor(ctx: Context, number: String?): String? {
        if (number.isNullOrBlank() || !canReadContacts(ctx)) return null
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
        )
        ctx.contentResolver.query(
            uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    /** What the user is allowed to see: name for saved contacts, masked number otherwise. */
    fun displayLabel(ctx: Context, number: String?): String {
        if (number.isNullOrBlank()) return "Unknown caller"
        return nameFor(ctx, number) ?: mask(number)
    }

    /** 9876543210 -> 98••••••10 */
    fun mask(number: String): String {
        val digits = number.filter { it.isDigit() || it == '+' }
        if (digits.length <= 4) return "Unknown caller"
        return digits.take(2) + "•".repeat(digits.length - 4) + digits.takeLast(2)
    }

    /** All saved contacts, name only in the UI (number kept internally for dialing). */
    fun allContacts(ctx: Context): List<Entry> {
        if (!canReadContacts(ctx)) return emptyList()
        val out = LinkedHashMap<String, Entry>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
        )?.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                if (!out.containsKey(name)) out[name] = Entry(name, num)
            }
        }
        return out.values.toList()
    }
}
