package com.example.nameonlydialer

import android.telecom.Call

/** Tiny shared holder so the service and the call screen can talk. */
object CallManager {
    var call: Call? = null
        private set
    var service: CallService? = null
    var onChange: (() -> Unit)? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            onChange?.invoke()
        }
    }

    fun set(newCall: Call) {
        call?.unregisterCallback(callback)
        call = newCall
        newCall.registerCallback(callback)
        onChange?.invoke()
    }

    fun clear(removed: Call) {
        if (call == removed) {
            removed.unregisterCallback(callback)
            call = null
            onChange?.invoke()
        }
    }

    fun number(): String? = call?.details?.handle?.schemeSpecificPart
}
