package com.example.nameonlydialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.telecom.TelecomManager
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var btnDefault: Button
    private lateinit var etNumber: EditText
    private lateinit var list: ListView

    private var entries: List<Entry> = emptyList()

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refreshStatus() }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            showRecents()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvDefaultStatus)
        btnDefault = findViewById(R.id.btnDefault)
        etNumber = findViewById(R.id.etNumber)
        list = findViewById(R.id.list)

        btnDefault.setOnClickListener { requestDialerRole() }
        findViewById<Button>(R.id.btnCall).setOnClickListener {
            placeCall(etNumber.text.toString().trim())
        }
        findViewById<Button>(R.id.btnRecents).setOnClickListener { showRecents() }
        findViewById<Button>(R.id.btnContacts).setOnClickListener { showContacts() }

        list.setOnItemClickListener { _, _, pos, _ -> placeCall(entries[pos].number) }

        // If another app sent us tel:xxxx, prefill the pad.
        intent?.data?.schemeSpecificPart?.let { etNumber.setText(it) }

        askPermissions()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) showRecents() else permLauncher.launch(missing.toTypedArray())
    }

    private fun requestDialerRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        }
    }

    private fun refreshStatus() {
        val rm = getSystemService(RoleManager::class.java)
        val held = rm.isRoleHeld(RoleManager.ROLE_DIALER)
        tvStatus.text = if (held) "✔ This app is your default Phone app. Numbers of saved contacts are hidden."
        else "Set this app as the default Phone app, otherwise numbers will still show in the system dialer."
        btnDefault.visibility = if (held) View.GONE else View.VISIBLE
    }

    private fun placeCall(number: String) {
        if (number.isBlank()) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            askPermissions(); return
        }
        val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        tm.placeCall(Uri.fromParts("tel", number, null), null)
    }

    /** Recent calls – the list only displays names (or masked numbers for strangers). */
    private fun showRecents() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val out = mutableListOf<Entry>()
        contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER),
            null, null, CallLog.Calls.DATE + " DESC"
        )?.use {
            while (it.moveToNext() && out.size < 50) {
                val num = it.getString(0) ?: continue
                out += Entry(ContactResolver.displayLabel(this, num), num)
            }
        }
        setEntries(out)
    }

    private fun showContacts() = setEntries(ContactResolver.allContacts(this))

    private fun setEntries(items: List<Entry>) {
        entries = items
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1, items.map { it.name }
        )
        if (items.isEmpty()) {
            Toast.makeText(this, "Nothing to show (check permissions)", Toast.LENGTH_SHORT).show()
        }
    }
}
